import React from "react";
import { FaSearch } from "react-icons/fa";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Search = () => {
  const [keyword, setKeyword] = useState("");
  const navigate = useNavigate();

  const searchHandler = () => {
    navigate("/search?keyword=" + keyword);
  };
  return (
    <div>
      <div className="input-group">
        <input
          type="text"
          id="search_field"
          onChange={(e) => setKeyword(e.target.value)}
          className="form-control"
          onBlur={searchHandler}
          placeholder="Enter Product Name ..."
        />
        <div className="input-group-append">
          <button onClick={searchHandler} id="search_btn" className="btn">
            <FaSearch aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Search;
